<html>
	
	<head>
		<title>PhpTask3lab10PartB</title>
		<?php 
if (isset($_POST['reading'])){
$myfile = fopen("roll.txt", "r") ;
echo $myfile;
echo fread($myfile,filesize("roll.txt"));

}

if (isset($_POST['writing'])) {

	$file = fopen("roll.txt","w");
echo fwrite($file," lab10 task2PartB.. Hello world ");
fclose($file);
}
if (isset($_POST['copy'])) {
$fn = './roll.txt';    
 $newfn = './roll2.txt'; 
 
 if(copy($fn,$newfn))
 echo 'The file was copied successfully';
 else
 echo 'An error occurred during copying the file';
}

if (isset($_POST['rename'])) {
	$old_name = "roll2.txt" ;  
  
$new_name = "roll1.txt" ;  
 
if(rename( $old_name, $new_name)) 
	echo 'Successfuly rename';
else 
	echo 'not rename';
}

if (isset($_POST['delete'])) {
	$file="roll1.txt";
	if(unlink($file))
		echo 'successfully delete';
	else
				echo 'not delete';
}
		 ?>
	</head>
	<body>
		<form  method="post">
			<input type="submit" name="reading" value="Reading">
			<input type="submit" name="writing" value="writing">
			<input type="submit" name="copy" value="copy">
			<input type="submit" name="rename" value="rename">
			<input type="submit" name="delete" value="delete">
		</form>
	</body>
</html>
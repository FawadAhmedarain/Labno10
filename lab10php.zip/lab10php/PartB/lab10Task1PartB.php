<html>
<head>
	<title>
		Lab10Task1PartB
	</title>
<?php 
if (isset ( $_FILES['upload'] ) ) {

    $file_size = $_FILES['upload']['size'];
    $file_type = $_FILES['upload']['type'];

    if (($file_size > 2097152)&&  ($file_type != "application/pdf") &&
    
        ($file_type != "image/jpg") &&
        
        ($file_type != "image/png")   ){      
        store_uploaded_file($id);
    }
    else   
        
    {
        $message = 'Invalid file type. Only PDF, JPG, GIF and PNG types are accepted.'; 
        echo '<script type="text/javascript">alert("'.$message.'");</script>';         
    }    
    
}
   ?>
</head>
<body>
	<form method="post">
		<input type="file" name="fileupload" value="FileUploader">
			<input type="submit" name="sub" value="Upload">
	</form>
</body>
</html>
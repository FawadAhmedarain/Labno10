<?php

$file = 'roll.txt';
$fileread = file($file);
print_r($fileread);
//append
$handle = fopen($file, 'a');
$data = '16SW01';
$result=fwrite($handle,$data);
if($result)
	echo "written succesfully";

else
	echo "problem in writing to file";



fclose($handle);

$dfile = file($file);
echo (implode($dfile));
?>